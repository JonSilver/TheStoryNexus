import { chromium } from 'playwright';

const BASE = process.env.SPIKE_URL ?? 'http://localhost:4173';

const results = [];
const record = (name, pass, detail) => {
    results.push({ name, pass, detail });
    console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

const readJson = async (page) => {
    await page.getByTestId('tab-json').click();
    return JSON.parse(await page.getByTestId('panel-json').innerText());
};

const findBeat = (json) =>
    (json.root?.children ?? []).find((c) => c.type === 'scene-beat') ?? null;

const editorText = (page) => page.getByTestId('editor').innerText();

const undoDepth = async (page) => {
    // Count how many undos are needed before the Undo button disables.
    let count = 0;
    while (await page.getByTestId('undo').isEnabled()) {
        await page.getByTestId('undo').click();
        count += 1;
        if (count > 40) break;
    }
    return count;
};

const run = async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext({
        permissions: ['clipboard-read', 'clipboard-write'],
    });
    const page = await context.newPage();
    const consoleErrors = [];
    page.on('pageerror', (e) => consoleErrors.push(String(e)));
    page.on('console', (m) => m.type() === 'error' && consoleErrors.push(m.text()));

    await page.goto(BASE);
    await page.getByTestId('editor').waitFor();

    // ---- 1. Seeded scene beat serialises its full state -------------------
    const seeded = findBeat(await readJson(page));
    record(
        '1. scene-beat node present in editor-state JSON',
        seeded !== null,
        seeded ? `keys: ${Object.keys(seeded).join(',')}` : 'no scene-beat node',
    );
    record(
        '1b. command persisted in JSON without custom exportJSON',
        seeded?.command === 'She confronts the harbourmaster.',
        JSON.stringify(seeded?.command),
    );

    // ---- 2. Streaming into node state while typing elsewhere --------------
    const beat = page.locator('.scene-beat').first();
    await beat.getByRole('button', { name: 'Generate' }).click();
    await page.waitForTimeout(300);

    // Type into the trailing paragraph mid-stream.
    const trailing = page
        .getByTestId('editor')
        .locator('p')
        .filter({ hasText: 'Type here while a beat is streaming' });
    await trailing.click();
    await page.keyboard.press('End');
    await page.keyboard.type(' CONCURRENT');
    await page.waitForTimeout(200);
    const midStreamStatus = await beat.getAttribute('data-status');
    await page.keyboard.type('-TWO');

    await beat.getByRole('button', { name: 'Accept' }).waitFor({ timeout: 15000 });
    const afterStream = await editorText(page);
    record(
        '2. typing during stream is not corrupted',
        afterStream.includes('CONCURRENT-TWO'),
        `status mid-stream=${midStreamStatus}`,
    );
    const streamedBeat = findBeat(await readJson(page));
    record(
        '2b. streamed text lives in the document JSON (node-state mode)',
        (streamedBeat?.generatedText ?? '').length > 50 && streamedBeat?.status === 'done',
        `${(streamedBeat?.generatedText ?? '').length} chars, status=${streamedBeat?.status}`,
    );

    // ---- 3. Accept + single undo ----------------------------------------
    const beforeAccept = await editorText(page);
    const paragraphsBefore = (await readJson(page)).root.children.filter(
        (c) => c.type === 'paragraph',
    ).length;
    await beat.getByRole('button', { name: 'Accept' }).click();
    await page.waitForTimeout(150);
    const acceptedJson = await readJson(page);
    const paragraphsAfter = acceptedJson.root.children.filter((c) => c.type === 'paragraph').length;
    const acceptedBeat = findBeat(acceptedJson);
    record(
        '3. accept inserts real paragraphs and marks node accepted',
        paragraphsAfter > paragraphsBefore && acceptedBeat?.status === 'accepted',
        `paragraphs ${paragraphsBefore} -> ${paragraphsAfter}, status=${acceptedBeat?.status}, generatedText cleared=${!acceptedBeat?.generatedText}`,
    );

    await page.getByTestId('undo').click();
    await page.waitForTimeout(150);
    const afterUndo = await editorText(page);
    const undoneBeat = findBeat(await readJson(page));
    record(
        '3b. ONE undo fully reverts accept (prose removed, text restored)',
        afterUndo.trim() === beforeAccept.trim() &&
            undoneBeat?.status === 'done' &&
            (undoneBeat?.generatedText ?? '').length > 50,
        `status=${undoneBeat?.status}, text=${(undoneBeat?.generatedText ?? '').length} chars`,
    );

    // ---- 4. How many undo steps did the whole stream cost? ---------------
    const depth = await undoDepth(page);
    record(
        '4. total undo steps for seed+stream+typing (history-merge working)',
        depth <= 12,
        `${depth} undo steps to exhaust history`,
    );

    // ---- 5. Round-trip through JSON --------------------------------------
    await page.reload();
    await page.getByTestId('editor').waitFor();
    await page.getByTestId('round-trip').click();
    await page.waitForTimeout(100);
    const rt = await page.getByTestId('round-trip-result').innerText();
    record('5. serialise -> parse -> serialise is identical', rt === 'round-trip identical', rt);

    // ---- 6. Copy / paste the decorator node ------------------------------
    // Generate first so command + status + generatedText are all non-default,
    // otherwise the copy proves nothing (defaults are omitted from JSON).
    const beatRt = page.locator('.scene-beat').first();
    await beatRt.getByRole('button', { name: 'Generate' }).click();
    await beatRt.getByRole('button', { name: 'Accept' }).waitFor({ timeout: 15000 });

    // Select the whole document and copy, then paste into the end.
    await page.getByTestId('editor').click();
    await page.keyboard.press('ControlOrMeta+A');
    await page.keyboard.press('ControlOrMeta+C');
    await page.waitForTimeout(200);
    await page.keyboard.press('ControlOrMeta+End');
    await page.keyboard.press('Enter');
    await page.keyboard.press('ControlOrMeta+V');
    await page.waitForTimeout(400);
    const pastedJson = await readJson(page);
    const beats = (pastedJson.root?.children ?? []).filter((c) => c.type === 'scene-beat');
    record(
        '6. copy/paste duplicates the beat with ALL custom state intact',
        beats.length === 2 &&
            beats[1].command === beats[0].command &&
            beats[1].status === 'done' &&
            beats[1].generatedText === beats[0].generatedText &&
            beats[1].generatedText.length > 50,
        `${beats.length} beats; copy: status=${beats[1]?.status}, generatedText=${
            (beats[1]?.generatedText ?? '').length
        } chars, command match=${beats[1]?.command === beats[0]?.command}`,
    );

    // What does the OS clipboard actually carry for other apps?
    const clip = await page.evaluate(async () => {
        const items = await navigator.clipboard.read();
        const types = items.flatMap((i) => i.types);
        const text = await navigator.clipboard.readText();
        return { types, text };
    });
    record(
        '6b. clipboard payload for EXTERNAL apps (no exportDOM on the beat)',
        true,
        `types=${clip.types.join(',')}; plain-text mentions beat command: ${clip.text.includes(
            'harbourmaster',
        )}`,
    );

    // ---- 7. Markdown export ---------------------------------------------
    await page.getByTestId('tab-markdown').click();
    const md = await page.getByTestId('panel-markdown').innerText();
    record(
        '7. markdown export: heading + emphasis, scene beats omitted',
        md.includes('# Chapter One') &&
            md.includes('_unusually_') &&
            md.includes('**Mara**') &&
            !md.toLowerCase().includes('harbourmaster.') &&
            !md.includes('Lorem ipsum'),
        md.split('\n').slice(0, 4).join(' / '),
    );

    // ---- 8. react-state streaming mode for comparison --------------------
    await page.reload();
    await page.getByTestId('editor').waitFor();
    await page.getByTestId('stream-mode').selectOption('react-state');
    const beat2 = page.locator('.scene-beat').first();
    await beat2.getByRole('button', { name: 'Generate' }).click();
    await page.waitForTimeout(400);
    const midJson = findBeat(await readJson(page));
    const visibleMid = await beat2.locator('.scene-beat__output').innerText();
    record(
        '8. react-state mode: text visible on screen but NOT yet in document',
        visibleMid.length > 10 && !midJson?.generatedText,
        `on-screen=${visibleMid.length} chars, in-json=${(midJson?.generatedText ?? '').length} chars`,
    );
    await beat2.getByRole('button', { name: 'Accept' }).waitFor({ timeout: 15000 });
    const finalJson = findBeat(await readJson(page));
    record(
        '8b. react-state mode commits once at end of stream',
        (finalJson?.generatedText ?? '').length > 50,
        `${(finalJson?.generatedText ?? '').length} chars committed`,
    );

    // ---- 9. Typing latency: idle vs mid-stream ---------------------------
    const typeBurst = async () => {
        const trailingP = page
            .getByTestId('editor')
            .locator('p')
            .filter({ hasText: 'Type here while a beat is streaming' });
        await trailingP.click();
        await page.keyboard.press('End');
        const started = Date.now();
        await page.keyboard.type('abcdefghijklmnopqrstuvwxy', { delay: 0 });
        return Date.now() - started;
    };

    for (const mode of ['node-state', 'react-state']) {
        await page.reload();
        await page.getByTestId('editor').waitFor();
        await page.getByTestId('stream-mode').selectOption(mode);
        const idleMs = await typeBurst();
        const b = page.locator('.scene-beat').first();
        await b.getByRole('button', { name: 'Generate' }).click();
        await page.waitForTimeout(200);
        const busyMs = await typeBurst();
        record(
            `9. [${mode}] 25 keystrokes: idle ${idleMs}ms vs mid-stream ${busyMs}ms`,
            busyMs < idleMs * 3 + 150,
            `overhead ${busyMs - idleMs}ms`,
        );
    }

    // ---- 10. Typing in beat B's textarea while beat A streams ------------
    await page.reload();
    await page.getByTestId('editor').waitFor();
    await page.getByTestId('editor').click();
    await page.keyboard.press('ControlOrMeta+End');
    await page.getByTestId('insert-scene-beat').click();
    await page.waitForTimeout(100);
    const beatCount = await page.locator('.scene-beat').count();

    await page.locator('.scene-beat').first().getByRole('button', { name: 'Generate' }).click();
    await page.waitForTimeout(150);
    const otherCommand = page.locator('.scene-beat').last().locator('.scene-beat__command');
    await otherCommand.click();
    await otherCommand.fill('');
    await page.keyboard.type('The lighthouse keeper lies.', { delay: 12 });
    const typedValue = await otherCommand.inputValue();
    const stillFocused = await otherCommand.evaluate((el) => el === document.activeElement);
    record(
        '10. typing in one beat textarea while another streams (2 beats)',
        beatCount === 2 && typedValue === 'The lighthouse keeper lies.' && stillFocused,
        `value=${JSON.stringify(typedValue)}, kept focus=${stillFocused}`,
    );

    // Ctrl/Cmd+A while focus is inside a decorator <textarea>: is it scoped to
    // the textarea, or does Lexical hijack it into a whole-document select-all?
    await page.keyboard.press('ControlOrMeta+A');
    await page.waitForTimeout(80);
    const selectAllScope = await page.evaluate(() => {
        const ta = document.activeElement;
        const inTextarea = ta instanceof HTMLTextAreaElement;
        const textareaSelected = inTextarea && ta.selectionEnd - ta.selectionStart === ta.value.length;
        const docSelChars = String(window.getSelection() ?? '').length;
        return { inTextarea, textareaSelected, docSelChars };
    });
    record(
        '10b. Ctrl/Cmd+A inside a decorator textarea is scoped to the textarea',
        selectAllScope.inTextarea && selectAllScope.textareaSelected,
        `focus in textarea=${selectAllScope.inTextarea}, textarea fully selected=${selectAllScope.textareaSelected}, document selection=${selectAllScope.docSelChars} chars`,
    );
    await page
        .locator('.scene-beat')
        .first()
        .getByRole('button', { name: 'Stop' })
        .click()
        .catch(() => {});

    // ---- 11. Caret / delete interaction with the block decorator ---------
    await page.reload();
    await page.getByTestId('editor').waitFor();
    const trailing2 = page
        .getByTestId('editor')
        .locator('p')
        .filter({ hasText: 'Type here while a beat is streaming' });
    await trailing2.click();
    await page.keyboard.press('Home');
    await page.keyboard.press('Backspace'); // selects the beat
    const selectedAfterFirst = await page.locator('.scene-beat').count();
    await page.keyboard.press('Backspace'); // deletes it
    await page.waitForTimeout(100);
    const remaining = (await readJson(page)).root.children.filter(
        (c) => c.type === 'scene-beat',
    ).length;
    record(
        '11. Backspace from the paragraph after the beat selects then deletes it',
        remaining === 0,
        `beats after 1st Backspace=${selectedAfterFirst}, after 2nd=${remaining}`,
    );

    record('12. no uncaught page errors during run', consoleErrors.length === 0,
        consoleErrors.slice(0, 3).join(' | ') || 'clean');

    await browser.close();

    const failed = results.filter((r) => !r.pass);
    console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
    process.exit(failed.length === 0 ? 0 : 1);
};

run().catch((e) => {
    console.error(e);
    process.exit(1);
});
