import { DecoratorNode, createState, $getState, $setState, type LexicalNode } from 'lexical';
import type { JSX } from 'react';
import { SceneBeatComponent } from '../components/SceneBeatComponent';

export const SCENE_BEAT_STATUSES = ['idle', 'generating', 'done', 'accepted'] as const;
export type SceneBeatStatus = (typeof SCENE_BEAT_STATUSES)[number];

const isStatus = (v: unknown): v is SceneBeatStatus =>
    SCENE_BEAT_STATUSES.includes(v as SceneBeatStatus);

const asString = (v: unknown) => (typeof v === 'string' ? v : '');

/**
 * NodeState (Lexical >=0.28) — each entry serialises itself into the editor-state
 * JSON and is restored on import with no hand-written importJSON/exportJSON.
 * Values equal to the parse(undefined) default are omitted from JSON.
 */
export const commandState = createState('command', { parse: asString });
export const statusState = createState('status', {
    parse: (v): SceneBeatStatus => (isStatus(v) ? v : 'idle'),
});
export const generatedTextState = createState('generatedText', { parse: asString });

export type SceneBeatData = {
    command: string;
    status: SceneBeatStatus;
    generatedText: string;
};

export class SceneBeatNode extends DecoratorNode<JSX.Element> {
    $config() {
        return this.config('scene-beat', {
            extends: DecoratorNode,
            stateConfigs: [
                { stateConfig: commandState, flat: true },
                { stateConfig: statusState, flat: true },
                { stateConfig: generatedTextState, flat: true },
            ],
        });
    }

    createDOM(): HTMLElement {
        const el = document.createElement('div');
        el.className = 'scene-beat-host';
        return el;
    }

    updateDOM(): false {
        return false;
    }

    decorate(): JSX.Element {
        return <SceneBeatComponent nodeKey={this.getKey()} />;
    }

    isInline(): false {
        return false;
    }

    // Lets the caret step over the block and select it as a node (Backspace deletes it).
    isKeyboardSelectable(): true {
        return true;
    }
}

export const $createSceneBeatNode = (command = '') =>
    $setState(new SceneBeatNode(), commandState, command);

export const $isSceneBeatNode = (node: LexicalNode | null | undefined): node is SceneBeatNode =>
    node instanceof SceneBeatNode;

export const $readSceneBeat = (node: SceneBeatNode): SceneBeatData => ({
    command: $getState(node, commandState),
    status: $getState(node, statusState),
    generatedText: $getState(node, generatedTextState),
});
