const LOREM =
    `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`.split(
        /(\s+)/,
    );

export const TOKEN_INTERVAL_MS = 50;

/**
 * Emits lorem tokens on a fixed interval. Returns a cancel function; onDone
 * fires only on natural completion.
 */
export const startFakeStream = (
    onToken: (token: string) => void,
    onDone: () => void,
    tokenCount = 60,
) => {
    const tokens = LOREM.slice(0, tokenCount);
    let index = 0;
    const timer = setInterval(() => {
        if (index >= tokens.length) {
            clearInterval(timer);
            onDone();
            return;
        }
        onToken(tokens[index]);
        index += 1;
    }, TOKEN_INTERVAL_MS);
    return () => clearInterval(timer);
};
