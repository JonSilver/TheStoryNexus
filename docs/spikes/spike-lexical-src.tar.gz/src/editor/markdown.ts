/**
 * Editor-state JSON -> Markdown. Deliberately operates on the serialised JSON
 * (not the live editor) so export can run server-side on a stored document.
 */

type JsonNode = {
    type?: string;
    text?: string;
    format?: number | string;
    tag?: string;
    children?: JsonNode[];
    [key: string]: unknown;
};

export type EditorStateJson = { root?: JsonNode };

// Lexical TextNode format bitmask, innermost wrapper first.
const TEXT_MARKS = [
    { bit: 16, mark: '`' },
    { bit: 4, mark: '~~' },
    { bit: 2, mark: '_' },
    { bit: 1, mark: '**' },
] as const;

const HEADING_LEVELS: Record<string, number> = { h1: 1, h2: 2, h3: 3, h4: 4, h5: 5, h6: 6 };

const escapeMarkdown = (text: string) => text.replace(/([\\`*_[\]#])/g, '\\$1');

const serialiseText = (node: JsonNode) => {
    const raw = node.text ?? '';
    if (!raw) return '';
    const format = typeof node.format === 'number' ? node.format : 0;
    const isCode = (format & 16) !== 0;
    const body = isCode ? raw : escapeMarkdown(raw);
    return TEXT_MARKS.reduce(
        (acc, { bit, mark }) => ((format & bit) === 0 ? acc : `${mark}${acc}${mark}`),
        body,
    );
};

const INLINE_SERIALISERS: Record<string, (node: JsonNode) => string> = {
    text: serialiseText,
    linebreak: () => '  \n',
    tab: () => '\t',
};

const serialiseInline = (node: JsonNode): string =>
    (node.children ?? [])
        .map((child) => (INLINE_SERIALISERS[child.type ?? ''] ?? serialiseInline)(child))
        .join('');

const prefixLines = (text: string, prefix: string) =>
    text
        .split('\n')
        .map((line) => `${prefix}${line}`)
        .join('\n');

/**
 * null means "emit nothing". Scene beats are always null: a pending beat is an
 * instruction, not prose, and an accepted beat has already written real
 * paragraphs into the document.
 */
const BLOCK_SERIALISERS: Record<string, (node: JsonNode) => string | null> = {
    paragraph: (node) => serialiseInline(node).trimEnd() || null,
    heading: (node) => {
        const body = serialiseInline(node).trim();
        if (!body) return null;
        return `${'#'.repeat(HEADING_LEVELS[node.tag ?? 'h1'] ?? 1)} ${body}`;
    },
    quote: (node) => {
        const body = serialiseInline(node).trim();
        return body ? prefixLines(body, '> ') : null;
    },
    horizontalrule: () => '---',
    'scene-beat': () => null,
};

const serialiseBlock = (node: JsonNode): string | null => {
    const handler = BLOCK_SERIALISERS[node.type ?? ''];
    if (handler) return handler(node);
    // Unknown block: fall back to its inline content rather than losing prose.
    return serialiseInline(node).trim() || null;
};

export const editorStateToMarkdown = (state: EditorStateJson): string =>
    (state.root?.children ?? [])
        .map(serialiseBlock)
        .filter((block): block is string => block !== null)
        .join('\n\n')
        .concat('\n');
