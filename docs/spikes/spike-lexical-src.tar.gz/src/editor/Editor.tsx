import { LexicalComposer } from '@lexical/react/LexicalComposer';
import { RichTextPlugin } from '@lexical/react/LexicalRichTextPlugin';
import { ContentEditable } from '@lexical/react/LexicalContentEditable';
import { LexicalErrorBoundary } from '@lexical/react/LexicalErrorBoundary';
import { HistoryPlugin } from '@lexical/react/LexicalHistoryPlugin';
import { OnChangePlugin } from '@lexical/react/LexicalOnChangePlugin';
import { HorizontalRuleNode } from '@lexical/react/LexicalHorizontalRuleNode';
import { HeadingNode, QuoteNode } from '@lexical/rich-text';
import { $getRoot, $createParagraphNode, $createTextNode, type EditorState } from 'lexical';
import { $createHeadingNode } from '@lexical/rich-text';
import { SceneBeatNode, $createSceneBeatNode } from './nodes/SceneBeatNode';
import { ToolbarPlugin } from './plugins/ToolbarPlugin';
import { DevToolsPlugin } from './plugins/DevToolsPlugin';
import { EmitInitialStatePlugin } from './plugins/EmitInitialStatePlugin';
import { SpikeSettingsProvider } from './SpikeSettings';

const theme = {
    paragraph: 'ed-paragraph',
    heading: { h1: 'ed-h1', h2: 'ed-h2', h3: 'ed-h3' },
    quote: 'ed-quote',
    text: { bold: 'ed-bold', italic: 'ed-italic', code: 'ed-code' },
};

const seedDocument = () => {
    const root = $getRoot();
    if (root.getFirstChild()) return;

    const heading = $createHeadingNode('h1');
    heading.append($createTextNode('Chapter One'));

    const intro = $createParagraphNode();
    intro.append(
        $createTextNode('The harbour was '),
        $createTextNode('unusually').toggleFormat('italic'),
        $createTextNode(' quiet that morning, and '),
        $createTextNode('Mara').toggleFormat('bold'),
        $createTextNode(' noticed it before anyone else.'),
    );

    const trailing = $createParagraphNode();
    trailing.append($createTextNode('Type here while a beat is streaming to test interference.'));

    root.append(heading, intro, $createSceneBeatNode('She confronts the harbourmaster.'), trailing);
};

export const Editor = ({ onChange }: { onChange: (state: EditorState) => void }) => (
    <LexicalComposer
        initialConfig={{
            namespace: 'story-nexus-spike',
            theme,
            nodes: [HeadingNode, QuoteNode, HorizontalRuleNode, SceneBeatNode],
            editorState: seedDocument,
            onError: (error) => {
                throw error;
            },
        }}
    >
        <SpikeSettingsProvider>
            <ToolbarPlugin />
            <DevToolsPlugin />
            <RichTextPlugin
                contentEditable={
                    <ContentEditable className="editor-shell" data-testid="editor" />
                }
                ErrorBoundary={LexicalErrorBoundary}
            />
            <HistoryPlugin />
            <EmitInitialStatePlugin onState={onChange} />
            {/*
              ignoreHistoryMergeTagChange defaults to TRUE: without this the
              streamed tokens (tagged history-merge so they don't flood undo)
              never reach the change listener, and any autosave built on it
              silently loses the generated text.
            */}
            <OnChangePlugin
                onChange={onChange}
                ignoreSelectionChange
                ignoreHistoryMergeTagChange={false}
            />
        </SpikeSettingsProvider>
    </LexicalComposer>
);
