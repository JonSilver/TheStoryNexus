import { useEffect, useState } from 'react';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';

declare global {
    interface Window {
        __spikeEditor?: import('lexical').LexicalEditor;
    }
}

/**
 * Round-trips the document through JSON to prove the SceneBeat state survives
 * serialise -> parse with no bespoke import/export code. Also exposes the editor
 * for browser-driven tests.
 */
export const DevToolsPlugin = () => {
    const [editor] = useLexicalComposerContext();
    const [note, setNote] = useState('');

    useEffect(() => {
        window.__spikeEditor = editor;
        return () => {
            delete window.__spikeEditor;
        };
    }, [editor]);

    const roundTrip = () => {
        const before = JSON.stringify(editor.getEditorState().toJSON());
        editor.setEditorState(editor.parseEditorState(before));
        const after = JSON.stringify(editor.getEditorState().toJSON());
        setNote(before === after ? 'round-trip identical' : 'round-trip DIFFERS');
    };

    return (
        <div className="devtools">
            <button type="button" data-testid="round-trip" onClick={roundTrip}>
                Round-trip through JSON
            </button>
            <span data-testid="round-trip-result">{note}</span>
        </div>
    );
};
