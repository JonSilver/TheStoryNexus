import { useEffect, useState } from 'react';
import {
    $getSelection,
    $isRangeSelection,
    $createParagraphNode,
    CAN_REDO_COMMAND,
    CAN_UNDO_COMMAND,
    COMMAND_PRIORITY_LOW,
    FORMAT_TEXT_COMMAND,
    REDO_COMMAND,
    SELECTION_CHANGE_COMMAND,
    UNDO_COMMAND,
    type TextFormatType,
} from 'lexical';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';
import { $createHeadingNode, type HeadingTagType } from '@lexical/rich-text';
import { $setBlocksType } from '@lexical/selection';
import { $insertNodeToNearestRoot, mergeRegister } from '@lexical/utils';
import { INSERT_HORIZONTAL_RULE_COMMAND } from '@lexical/react/LexicalHorizontalRuleNode';
import { $createSceneBeatNode } from '../nodes/SceneBeatNode';
import { STREAM_MODES, useSpikeSettings } from '../SpikeSettings';

const INLINE_FORMATS: { format: TextFormatType; label: string }[] = [
    { format: 'bold', label: 'B' },
    { format: 'italic', label: 'I' },
];

const BLOCK_TYPES: { tag: HeadingTagType | 'paragraph'; label: string }[] = [
    { tag: 'paragraph', label: 'P' },
    { tag: 'h1', label: 'H1' },
    { tag: 'h2', label: 'H2' },
    { tag: 'h3', label: 'H3' },
];

export const ToolbarPlugin = () => {
    const [editor] = useLexicalComposerContext();
    const { streamMode, setStreamMode } = useSpikeSettings();
    const [activeFormats, setActiveFormats] = useState<Set<TextFormatType>>(new Set());
    const [canUndo, setCanUndo] = useState(false);
    const [canRedo, setCanRedo] = useState(false);

    useEffect(
        () =>
            mergeRegister(
                editor.registerCommand(
                    SELECTION_CHANGE_COMMAND,
                    () => {
                        const selection = $getSelection();
                        if ($isRangeSelection(selection))
                            setActiveFormats(
                                new Set(
                                    INLINE_FORMATS.map(({ format }) => format).filter((f) =>
                                        selection.hasFormat(f),
                                    ),
                                ),
                            );
                        return false;
                    },
                    COMMAND_PRIORITY_LOW,
                ),
                editor.registerCommand(
                    CAN_UNDO_COMMAND,
                    (payload) => {
                        setCanUndo(payload);
                        return false;
                    },
                    COMMAND_PRIORITY_LOW,
                ),
                editor.registerCommand(
                    CAN_REDO_COMMAND,
                    (payload) => {
                        setCanRedo(payload);
                        return false;
                    },
                    COMMAND_PRIORITY_LOW,
                ),
            ),
        [editor],
    );

    const setBlockType = (tag: HeadingTagType | 'paragraph') =>
        editor.update(() => {
            const selection = $getSelection();
            if (!$isRangeSelection(selection)) return;
            $setBlocksType(selection, () =>
                tag === 'paragraph' ? $createParagraphNode() : $createHeadingNode(tag),
            );
        });

    const insertSceneBeat = () =>
        editor.update(() => {
            $insertNodeToNearestRoot($createSceneBeatNode('She finally tells him the truth.'));
        });

    return (
        <div className="toolbar">
            {INLINE_FORMATS.map(({ format, label }) => (
                <button
                    key={format}
                    type="button"
                    data-testid={`format-${format}`}
                    className={activeFormats.has(format) ? 'is-active' : ''}
                    onClick={() => editor.dispatchCommand(FORMAT_TEXT_COMMAND, format)}
                >
                    {label}
                </button>
            ))}
            <span className="toolbar__sep" />
            {BLOCK_TYPES.map(({ tag, label }) => (
                <button
                    key={tag}
                    type="button"
                    data-testid={`block-${tag}`}
                    onClick={() => setBlockType(tag)}
                >
                    {label}
                </button>
            ))}
            <span className="toolbar__sep" />
            <button
                type="button"
                data-testid="insert-hr"
                onClick={() => editor.dispatchCommand(INSERT_HORIZONTAL_RULE_COMMAND, undefined)}
            >
                ―
            </button>
            <button
                type="button"
                data-testid="insert-scene-beat"
                className="is-primary"
                onClick={insertSceneBeat}
            >
                + Scene Beat
            </button>
            <span className="toolbar__sep" />
            <button
                type="button"
                data-testid="undo"
                disabled={!canUndo}
                onClick={() => editor.dispatchCommand(UNDO_COMMAND, undefined)}
            >
                Undo
            </button>
            <button
                type="button"
                data-testid="redo"
                disabled={!canRedo}
                onClick={() => editor.dispatchCommand(REDO_COMMAND, undefined)}
            >
                Redo
            </button>
            <label className="toolbar__mode">
                stream via
                <select
                    data-testid="stream-mode"
                    value={streamMode}
                    onChange={(e) => setStreamMode(e.target.value as (typeof STREAM_MODES)[number])}
                >
                    {STREAM_MODES.map((mode) => (
                        <option key={mode} value={mode}>
                            {mode}
                        </option>
                    ))}
                </select>
            </label>
        </div>
    );
};
