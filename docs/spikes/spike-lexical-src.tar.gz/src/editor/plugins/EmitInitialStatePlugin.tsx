import { useEffect } from 'react';
import type { EditorState } from 'lexical';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';

/**
 * OnChangePlugin never fires for the initial editor state (and skips the first
 * change when the previous state was empty), so anything mirroring the document
 * has to be primed once on mount.
 */
export const EmitInitialStatePlugin = ({ onState }: { onState: (s: EditorState) => void }) => {
    const [editor] = useLexicalComposerContext();
    useEffect(() => {
        onState(editor.getEditorState());
    }, [editor, onState]);
    return null;
};
