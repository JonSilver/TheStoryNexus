import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';

/**
 * node-state: every streamed token is written into the SceneBeatNode via
 *   editor.update (tagged history-merge) — the document is the source of truth.
 * react-state: tokens buffer in React; one editor.update commits at the end.
 */
export const STREAM_MODES = ['node-state', 'react-state'] as const;
export type StreamMode = (typeof STREAM_MODES)[number];

type Settings = { streamMode: StreamMode; setStreamMode: (m: StreamMode) => void };

const SpikeSettingsContext = createContext<Settings | null>(null);

export const SpikeSettingsProvider = ({ children }: { children: ReactNode }) => {
    const [streamMode, setStreamMode] = useState<StreamMode>('node-state');
    const value = useMemo(() => ({ streamMode, setStreamMode }), [streamMode]);
    return <SpikeSettingsContext value={value}>{children}</SpikeSettingsContext>;
};

export const useSpikeSettings = () => {
    const ctx = useContext(SpikeSettingsContext);
    if (!ctx) throw new Error('useSpikeSettings outside provider');
    return ctx;
};
