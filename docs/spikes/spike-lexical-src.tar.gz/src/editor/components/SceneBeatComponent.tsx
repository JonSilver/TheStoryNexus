import { useCallback, useEffect, useRef, useState } from 'react';
import {
    $getNodeByKey,
    $createParagraphNode,
    $createTextNode,
    HISTORY_MERGE_TAG,
    HISTORY_PUSH_TAG,
    SKIP_SCROLL_INTO_VIEW_TAG,
    $setState,
    $getState,
    type LexicalNode,
    type NodeKey,
    type UpdateTag,
} from 'lexical';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';
import {
    $isSceneBeatNode,
    commandState,
    generatedTextState,
    statusState,
    type SceneBeatNode,
} from '../nodes/SceneBeatNode';
import { useSceneBeatData } from '../useSceneBeatData';
import { startFakeStream } from '../fakeStream';
import { useSpikeSettings } from '../SpikeSettings';

export const SceneBeatComponent = ({ nodeKey }: { nodeKey: NodeKey }) => {
    const [editor] = useLexicalComposerContext();
    const { streamMode } = useSpikeSettings();
    const { command, status, generatedText } = useSceneBeatData(nodeKey);
    const [buffered, setBuffered] = useState<string | null>(null);
    const bufferRef = useRef('');
    const cancelRef = useRef<(() => void) | null>(null);

    const mutate = useCallback(
        (fn: (node: SceneBeatNode) => void, tag: UpdateTag | UpdateTag[], onUpdate?: () => void) =>
            editor.update(
                () => {
                    const node = $getNodeByKey(nodeKey);
                    if ($isSceneBeatNode(node)) fn(node);
                },
                { tag, onUpdate },
            ),
        [editor, nodeKey],
    );

    useEffect(() => () => cancelRef.current?.(), []);

    /**
     * Lexical's keydown listener sits on the contenteditable root, which is
     * BELOW the React root container — so a React onKeyDown handler runs too
     * late to stop it and shortcuts like Ctrl/Cmd+A get swallowed by the editor
     * instead of applying to this textarea. A native listener is required.
     */
    const isolateKeys = useCallback((el: HTMLTextAreaElement | null) => {
        if (!el) return;
        const stop = (e: KeyboardEvent) => e.stopPropagation();
        el.addEventListener('keydown', stop);
        return () => el.removeEventListener('keydown', stop);
    }, []);

    const generate = () => {
        cancelRef.current?.();
        const useNodeState = streamMode === 'node-state';

        mutate(
            (node) => {
                $setState(node, statusState, 'generating');
                $setState(node, generatedTextState, '');
            },
            HISTORY_PUSH_TAG,
        );
        bufferRef.current = '';
        if (!useNodeState) setBuffered('');

        const appendToNode = (token: string) =>
            mutate(
                (node) => $setState(node, generatedTextState, (prev) => prev + token),
                // history-merge keeps 20 writes/sec out of the undo stack;
                // skip-scroll-into-view stops the viewport chasing the stream.
                [HISTORY_MERGE_TAG, SKIP_SCROLL_INTO_VIEW_TAG],
            );

        const bufferToken = (token: string) => {
            bufferRef.current += token;
            setBuffered(bufferRef.current);
        };

        cancelRef.current = startFakeStream(
            (token) => (useNodeState ? appendToNode(token) : bufferToken(token)),
            () => {
                cancelRef.current = null;
                if (useNodeState) {
                    mutate((node) => $setState(node, statusState, 'done'), HISTORY_MERGE_TAG);
                    return;
                }
                const finalText = bufferRef.current;
                mutate(
                    (node) => {
                        $setState(node, generatedTextState, finalText);
                        $setState(node, statusState, 'done');
                    },
                    HISTORY_MERGE_TAG,
                    () => setBuffered(null),
                );
            },
        );
    };

    const accept = () =>
        mutate((node) => {
            const text = $getState(node, generatedTextState);
            const paragraphs = text
                .split(/\n{2,}/)
                .map((p) => p.trim())
                .filter(Boolean)
                .map((p) => {
                    const paragraph = $createParagraphNode();
                    paragraph.append($createTextNode(p));
                    return paragraph;
                });
            paragraphs.reduce<LexicalNode>((prev, p) => {
                prev.insertAfter(p);
                return p;
            }, node);
            $setState(node, statusState, 'accepted');
            $setState(node, generatedTextState, '');
            paragraphs.at(-1)?.selectEnd();
        }, HISTORY_PUSH_TAG);

    const reject = () =>
        mutate((node) => {
            $setState(node, statusState, 'idle');
            $setState(node, generatedTextState, '');
        }, HISTORY_PUSH_TAG);

    const stop = () => {
        cancelRef.current?.();
        cancelRef.current = null;
        const finalText = bufferRef.current;
        mutate(
            (node) => {
                if (streamMode === 'react-state')
                    $setState(node, generatedTextState, finalText);
                $setState(node, statusState, 'done');
            },
            HISTORY_PUSH_TAG,
            () => setBuffered(null),
        );
    };

    const displayed = buffered ?? generatedText;
    const isGenerating = status === 'generating';

    return (
        <div className="scene-beat" data-status={status} data-node-key={nodeKey}>
            <header className="scene-beat__bar">
                <span className="scene-beat__badge">Scene Beat</span>
                <span className="scene-beat__status">{status}</span>
            </header>

            <textarea
                ref={isolateKeys}
                className="scene-beat__command"
                value={command}
                rows={2}
                placeholder="Describe what happens in this beat…"
                disabled={isGenerating}
                onChange={(e) => {
                    const next = e.target.value;
                    mutate((node) => $setState(node, commandState, next), HISTORY_MERGE_TAG);
                }}
            />

            {displayed && <div className="scene-beat__output">{displayed}</div>}

            <footer className="scene-beat__actions">
                {isGenerating ? (
                    <button type="button" onClick={stop}>
                        Stop
                    </button>
                ) : (
                    <button type="button" onClick={generate} disabled={!command.trim()}>
                        {status === 'accepted' ? 'Regenerate' : 'Generate'}
                    </button>
                )}
                {status === 'done' && displayed && (
                    <>
                        <button type="button" className="is-primary" onClick={accept}>
                            Accept
                        </button>
                        <button type="button" onClick={reject}>
                            Reject
                        </button>
                    </>
                )}
            </footer>
        </div>
    );
};
