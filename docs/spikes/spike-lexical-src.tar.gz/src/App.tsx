import { useCallback, useMemo, useState } from 'react';
import type { EditorState } from 'lexical';
import { Editor } from './editor/Editor';
import { editorStateToMarkdown, type EditorStateJson } from './editor/markdown';

const PANELS = ['markdown', 'json'] as const;
type Panel = (typeof PANELS)[number];

export const App = () => {
    const [stateJson, setStateJson] = useState<EditorStateJson>({});
    const [panel, setPanel] = useState<Panel>('markdown');

    const handleChange = useCallback(
        (state: EditorState) => setStateJson(state.toJSON() as EditorStateJson),
        [],
    );

    const markdown = useMemo(() => editorStateToMarkdown(stateJson), [stateJson]);
    const json = useMemo(() => JSON.stringify(stateJson, null, 2), [stateJson]);

    return (
        <main className="app">
            <section className="app__editor">
                <Editor onChange={handleChange} />
            </section>
            <aside className="app__panel">
                <nav className="panel-tabs">
                    {PANELS.map((name) => (
                        <button
                            key={name}
                            type="button"
                            data-testid={`tab-${name}`}
                            className={panel === name ? 'is-active' : ''}
                            onClick={() => setPanel(name)}
                        >
                            {name}
                        </button>
                    ))}
                </nav>
                <pre className="panel-body" data-testid={`panel-${panel}`}>
                    {panel === 'markdown' ? markdown : json}
                </pre>
            </aside>
        </main>
    );
};
